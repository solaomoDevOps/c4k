<?php
require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];
$data = getRequestData();

$db = new Database();
$conn = $db->getConnection();

if (!$conn) {
    sendError('Database connection failed', 500);
}

if ($method === 'POST') {
    $action = $_GET['action'] ?? '';

    if ($action === 'google') {
        $credential = $data['credential'] ?? '';

        if (empty($credential)) {
            sendError('Google credential is required');
        }

        $parts = explode('.', $credential);
        if (count($parts) !== 3) {
            sendError('Invalid Google credential format');
        }

        $payload = json_decode(base64_decode(str_replace(['-', '_'], ['+', '/'], $parts[1])), true);

        if (!$payload || !isset($payload['email'])) {
            sendError('Invalid Google credential');
        }

        $email = $payload['email'];
        $googleId = $payload['sub'] ?? '';
        $name = $payload['name'] ?? '';
        $emailVerified = $payload['email_verified'] ?? false;

        if (!$emailVerified) {
            sendError('Google email not verified');
        }

        $query = "SELECT id, email FROM users WHERE email = :email LIMIT 1";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        $user = $stmt->fetch();

        if ($user) {
            $token = generateToken($user['id'], $user['email']);

            sendResponse([
                'user' => [
                    'id' => $user['id'],
                    'email' => $user['email'],
                    'email_verified' => true
                ],
                'token' => $token
            ]);
        } else {
            $passwordHash = password_hash(bin2hex(random_bytes(32)), PASSWORD_DEFAULT);

            $insertQuery = "INSERT INTO users (email, password_hash, email_verified)
                           VALUES (:email, :password_hash, TRUE)";
            $insertStmt = $conn->prepare($insertQuery);
            $insertStmt->bindParam(':email', $email);
            $insertStmt->bindParam(':password_hash', $passwordHash);

            if ($insertStmt->execute()) {
                $userId = $conn->lastInsertId();
                $token = generateToken($userId, $email);

                sendResponse([
                    'user' => [
                        'id' => $userId,
                        'email' => $email,
                        'email_verified' => true
                    ],
                    'token' => $token
                ]);
            } else {
                sendError('Failed to create account', 500);
            }
        }
    } else {
        sendError('Invalid action', 400);
    }
} else {
    sendError('Method not allowed', 405);
}
