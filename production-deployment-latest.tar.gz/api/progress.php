<?php
require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];
$data = getRequestData();

$db = new Database();
$conn = $db->getConnection();

if (!$conn) {
    sendError('Database connection failed', 500);
}

if ($method === 'GET') {
    $childId = $_GET['child_id'] ?? 0;

    if (!$childId) {
        sendError('Child ID is required');
    }

    $query = "SELECT * FROM progress WHERE child_id = :child_id ORDER BY created_at DESC";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':child_id', $childId);
    $stmt->execute();

    $progress = $stmt->fetchAll();

    sendResponse(['progress' => $progress]);
} elseif ($method === 'POST') {
    $childId = $data['child_id'] ?? 0;
    $lessonId = $data['lesson_id'] ?? 0;
    $completed = $data['completed'] ?? false;
    $score = $data['score'] ?? 0;
    $timeSpent = $data['time_spent'] ?? 0;

    if (!$childId || !$lessonId) {
        sendError('Child ID and Lesson ID are required');
    }

    $checkQuery = "SELECT id, attempts, time_spent FROM progress
                   WHERE child_id = :child_id AND lesson_id = :lesson_id LIMIT 1";
    $checkStmt = $conn->prepare($checkQuery);
    $checkStmt->bindParam(':child_id', $childId);
    $checkStmt->bindParam(':lesson_id', $lessonId);
    $checkStmt->execute();

    $existing = $checkStmt->fetch();

    if ($existing) {
        $newAttempts = $existing['attempts'] + 1;
        $newTimeSpent = $existing['time_spent'] + $timeSpent;
        $completedAt = $completed ? date('Y-m-d H:i:s') : null;

        $query = "UPDATE progress
                  SET completed = :completed,
                      score = :score,
                      attempts = :attempts,
                      time_spent = :time_spent,
                      completed_at = :completed_at
                  WHERE id = :id";

        $stmt = $conn->prepare($query);
        $stmt->bindParam(':completed', $completed, PDO::PARAM_BOOL);
        $stmt->bindParam(':score', $score);
        $stmt->bindParam(':attempts', $newAttempts);
        $stmt->bindParam(':time_spent', $newTimeSpent);
        $stmt->bindParam(':completed_at', $completedAt);
        $stmt->bindParam(':id', $existing['id']);
    } else {
        $completedAt = $completed ? date('Y-m-d H:i:s') : null;

        $query = "INSERT INTO progress
                  (child_id, lesson_id, completed, score, attempts, time_spent, completed_at)
                  VALUES (:child_id, :lesson_id, :completed, :score, 1, :time_spent, :completed_at)";

        $stmt = $conn->prepare($query);
        $stmt->bindParam(':child_id', $childId);
        $stmt->bindParam(':lesson_id', $lessonId);
        $stmt->bindParam(':completed', $completed, PDO::PARAM_BOOL);
        $stmt->bindParam(':score', $score);
        $stmt->bindParam(':time_spent', $timeSpent);
        $stmt->bindParam(':completed_at', $completedAt);
    }

    if ($stmt->execute()) {
        if (!$existing) {
            $progressId = $conn->lastInsertId();
        } else {
            $progressId = $existing['id'];
        }

        $progressQuery = "SELECT * FROM progress WHERE id = :id LIMIT 1";
        $progressStmt = $conn->prepare($progressQuery);
        $progressStmt->bindParam(':id', $progressId);
        $progressStmt->execute();

        $progress = $progressStmt->fetch();

        sendResponse(['progress' => $progress]);
    } else {
        sendError('Failed to save progress', 500);
    }
} else {
    sendError('Method not allowed', 405);
}
