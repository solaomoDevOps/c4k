<?php
require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];
$data = getRequestData();

$db = new Database();
$conn = $db->getConnection();

if (!$conn) {
    sendError('Database connection failed', 500);
}

if ($method === 'GET') {
    $childId = $_GET['child_id'] ?? 0;
    $action = $_GET['action'] ?? '';

    if (!$childId) {
        sendError('Child ID is required');
    }

    if ($action === 'check') {
        $today = date('Y-m-d');

        $query = "SELECT * FROM daily_rewards
                  WHERE child_id = :child_id AND reward_date = :today LIMIT 1";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':child_id', $childId);
        $stmt->bindParam(':today', $today);
        $stmt->execute();

        $reward = $stmt->fetch();

        sendResponse(['can_claim' => !$reward]);
    } else {
        $query = "SELECT * FROM daily_rewards
                  WHERE child_id = :child_id ORDER BY reward_date DESC";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':child_id', $childId);
        $stmt->execute();

        $rewards = $stmt->fetchAll();

        sendResponse(['rewards' => $rewards]);
    }
} elseif ($method === 'POST') {
    $childId = $data['child_id'] ?? 0;

    if (!$childId) {
        sendError('Child ID is required');
    }

    $today = date('Y-m-d');
    $yesterday = date('Y-m-d', strtotime('-1 day'));

    $checkQuery = "SELECT * FROM daily_rewards
                   WHERE child_id = :child_id AND reward_date = :today LIMIT 1";
    $checkStmt = $conn->prepare($checkQuery);
    $checkStmt->bindParam(':child_id', $childId);
    $checkStmt->bindParam(':today', $today);
    $checkStmt->execute();

    if ($checkStmt->fetch()) {
        sendError('Reward already claimed today');
    }

    $yesterdayQuery = "SELECT * FROM daily_rewards
                       WHERE child_id = :child_id AND reward_date = :yesterday LIMIT 1";
    $yesterdayStmt = $conn->prepare($yesterdayQuery);
    $yesterdayStmt->bindParam(':child_id', $childId);
    $yesterdayStmt->bindParam(':yesterday', $yesterday);
    $yesterdayStmt->execute();

    $hadYesterday = $yesterdayStmt->fetch();

    $childQuery = "SELECT current_streak FROM children WHERE id = :id LIMIT 1";
    $childStmt = $conn->prepare($childQuery);
    $childStmt->bindParam(':id', $childId);
    $childStmt->execute();
    $child = $childStmt->fetch();

    $newStreak = $hadYesterday ? ($child['current_streak'] + 1) : 1;

    $insertQuery = "INSERT INTO daily_rewards (child_id, reward_date, xp_earned)
                    VALUES (:child_id, :today, 10)";
    $insertStmt = $conn->prepare($insertQuery);
    $insertStmt->bindParam(':child_id', $childId);
    $insertStmt->bindParam(':today', $today);
    $insertStmt->execute();

    $updateChildQuery = "UPDATE children
                         SET current_streak = :streak,
                             xp = xp + 10,
                             level = FLOOR((xp + 10) / 100) + 1,
                             last_login_date = :today
                         WHERE id = :id";
    $updateStmt = $conn->prepare($updateChildQuery);
    $updateStmt->bindParam(':streak', $newStreak);
    $updateStmt->bindParam(':today', $today);
    $updateStmt->bindParam(':id', $childId);
    $updateStmt->execute();

    sendResponse(['success' => true, 'xp_earned' => 10, 'new_streak' => $newStreak]);
} else {
    sendError('Method not allowed', 405);
}
