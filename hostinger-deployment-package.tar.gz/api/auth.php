<?php
require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];
$data = getRequestData();

$db = new Database();
$conn = $db->getConnection();

if (!$conn) {
    sendError('Database connection failed', 500);
}

if ($method === 'POST') {
    $action = $_GET['action'] ?? '';

    if ($action === 'signup') {
        $email = $data['email'] ?? '';
        $password = $data['password'] ?? '';

        if (empty($email) || empty($password)) {
            sendError('Email and password are required');
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            sendError('Invalid email format');
        }

        if (strlen($password) < 6) {
            sendError('Password must be at least 6 characters');
        }

        $checkQuery = "SELECT id FROM users WHERE email = :email LIMIT 1";
        $stmt = $conn->prepare($checkQuery);
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        if ($stmt->fetch()) {
            sendError('Email already registered');
        }

        $passwordHash = password_hash($password, PASSWORD_DEFAULT);

        $query = "INSERT INTO users (email, password_hash) VALUES (:email, :password_hash)";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':password_hash', $passwordHash);

        if ($stmt->execute()) {
            $userId = $conn->lastInsertId();
            $token = generateToken($userId, $email);

            sendResponse([
                'user' => [
                    'id' => $userId,
                    'email' => $email
                ],
                'token' => $token
            ]);
        } else {
            sendError('Failed to create account', 500);
        }
    } elseif ($action === 'signin') {
        $email = $data['email'] ?? '';
        $password = $data['password'] ?? '';

        if (empty($email) || empty($password)) {
            sendError('Email and password are required');
        }

        $query = "SELECT id, email, password_hash FROM users WHERE email = :email LIMIT 1";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        $user = $stmt->fetch();

        if (!$user || !password_verify($password, $user['password_hash'])) {
            sendError('Invalid email or password', 401);
        }

        $token = generateToken($user['id'], $user['email']);

        sendResponse([
            'user' => [
                'id' => $user['id'],
                'email' => $user['email']
            ],
            'token' => $token
        ]);
    } else {
        sendError('Invalid action', 400);
    }
} elseif ($method === 'GET') {
    $token = getAuthToken();

    if (!$token) {
        sendError('No token provided', 401);
    }

    $user = verifyToken($token);

    if (!$user) {
        sendError('Invalid token', 401);
    }

    sendResponse(['user' => $user]);
} else {
    sendError('Method not allowed', 405);
}
