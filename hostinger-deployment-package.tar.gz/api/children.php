<?php
require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];
$data = getRequestData();

$db = new Database();
$conn = $db->getConnection();

if (!$conn) {
    sendError('Database connection failed', 500);
}

$token = getAuthToken();
$user = null;

if ($token) {
    $user = verifyToken($token);
}

if ($method === 'GET') {
    if (!$user) {
        sendError('Unauthorized', 401);
    }

    $query = "SELECT * FROM children WHERE user_id = :user_id ORDER BY created_at DESC";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':user_id', $user['id']);
    $stmt->execute();

    $children = $stmt->fetchAll();

    sendResponse(['children' => $children]);
} elseif ($method === 'POST') {
    $name = $data['name'] ?? '';
    $handPreference = $data['hand_preference'] ?? 'right';
    $computerType = $data['computer_type'] ?? 'pc';
    $careerRole = $data['career_role'] ?? null;
    $ageGroup = $data['age_group'] ?? '5-7';
    $userId = $user ? $user['id'] : null;

    if (empty($name)) {
        sendError('Name is required');
    }

    $query = "INSERT INTO children
              (user_id, name, hand_preference, computer_type, career_role, age_group)
              VALUES (:user_id, :name, :hand_preference, :computer_type, :career_role, :age_group)";

    $stmt = $conn->prepare($query);
    $stmt->bindParam(':user_id', $userId);
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':hand_preference', $handPreference);
    $stmt->bindParam(':computer_type', $computerType);
    $stmt->bindParam(':career_role', $careerRole);
    $stmt->bindParam(':age_group', $ageGroup);

    if ($stmt->execute()) {
        $childId = $conn->lastInsertId();

        $settingsQuery = "INSERT INTO settings (child_id) VALUES (:child_id)";
        $settingsStmt = $conn->prepare($settingsQuery);
        $settingsStmt->bindParam(':child_id', $childId);
        $settingsStmt->execute();

        $childQuery = "SELECT * FROM children WHERE id = :id LIMIT 1";
        $childStmt = $conn->prepare($childQuery);
        $childStmt->bindParam(':id', $childId);
        $childStmt->execute();

        $child = $childStmt->fetch();

        sendResponse(['child' => $child]);
    } else {
        sendError('Failed to create child profile', 500);
    }
} elseif ($method === 'PUT') {
    if (!$user) {
        sendError('Unauthorized', 401);
    }

    $childId = $_GET['id'] ?? 0;

    if (!$childId) {
        sendError('Child ID is required');
    }

    $checkQuery = "SELECT id FROM children WHERE id = :id AND user_id = :user_id LIMIT 1";
    $checkStmt = $conn->prepare($checkQuery);
    $checkStmt->bindParam(':id', $childId);
    $checkStmt->bindParam(':user_id', $user['id']);
    $checkStmt->execute();

    if (!$checkStmt->fetch()) {
        sendError('Child not found or unauthorized', 404);
    }

    $updateFields = [];
    $params = [':id' => $childId];

    $allowedFields = ['name', 'hand_preference', 'computer_type', 'selected_avatar',
                      'career_role', 'xp', 'level', 'current_streak', 'last_login_date'];

    foreach ($allowedFields as $field) {
        if (isset($data[$field])) {
            $updateFields[] = "$field = :$field";
            $params[":$field"] = $data[$field];
        }
    }

    if (empty($updateFields)) {
        sendError('No fields to update');
    }

    $query = "UPDATE children SET " . implode(', ', $updateFields) . " WHERE id = :id";
    $stmt = $conn->prepare($query);

    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }

    if ($stmt->execute()) {
        $childQuery = "SELECT * FROM children WHERE id = :id LIMIT 1";
        $childStmt = $conn->prepare($childQuery);
        $childStmt->bindParam(':id', $childId);
        $childStmt->execute();

        $child = $childStmt->fetch();

        sendResponse(['child' => $child]);
    } else {
        sendError('Failed to update child profile', 500);
    }
} else {
    sendError('Method not allowed', 405);
}
