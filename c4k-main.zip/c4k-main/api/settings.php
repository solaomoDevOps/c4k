<?php
require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];
$data = getRequestData();

$db = new Database();
$conn = $db->getConnection();

if (!$conn) {
    sendError('Database connection failed', 500);
}

if ($method === 'GET') {
    $childId = $_GET['child_id'] ?? 0;

    if (!$childId) {
        sendError('Child ID is required');
    }

    $query = "SELECT * FROM settings WHERE child_id = :child_id LIMIT 1";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':child_id', $childId);
    $stmt->execute();

    $settings = $stmt->fetch();

    if (!$settings) {
        $insertQuery = "INSERT INTO settings (child_id) VALUES (:child_id)";
        $insertStmt = $conn->prepare($insertQuery);
        $insertStmt->bindParam(':child_id', $childId);
        $insertStmt->execute();

        $stmt->execute();
        $settings = $stmt->fetch();
    }

    sendResponse(['settings' => $settings]);
} elseif ($method === 'PUT') {
    $childId = $_GET['child_id'] ?? 0;

    if (!$childId) {
        sendError('Child ID is required');
    }

    $updateFields = [];
    $params = [':child_id' => $childId];

    $allowedFields = ['audio_enabled', 'text_size', 'difficulty_level', 'screen_time_limit'];

    foreach ($allowedFields as $field) {
        if (isset($data[$field])) {
            $updateFields[] = "$field = :$field";
            $params[":$field"] = $data[$field];
        }
    }

    if (empty($updateFields)) {
        sendError('No fields to update');
    }

    $query = "UPDATE settings SET " . implode(', ', $updateFields) . " WHERE child_id = :child_id";
    $stmt = $conn->prepare($query);

    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }

    if ($stmt->execute()) {
        $settingsQuery = "SELECT * FROM settings WHERE child_id = :child_id LIMIT 1";
        $settingsStmt = $conn->prepare($settingsQuery);
        $settingsStmt->bindParam(':child_id', $childId);
        $settingsStmt->execute();

        $settings = $settingsStmt->fetch();

        sendResponse(['settings' => $settings]);
    } else {
        sendError('Failed to update settings', 500);
    }
} else {
    sendError('Method not allowed', 405);
}
