<?php
declare(strict_types=1);
require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/config.php';   // your DB wrapper, JWT secret, etc.

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use phpseclib3\Crypt\RSA;

// ---------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------
function sendJson(array $data, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}
function sendError(string $msg, int $code = 400): void
{
    sendJson(['error' => $msg], $code);
}

/**
 * Verify a Google ID token.
 *
 * @param string $idToken
 * @return array  Payload (claims) on success
 * @throws Exception on any verification failure
 */
function verifyGoogleIdToken(string $idToken): array
{
    // Split JWT
    $parts = explode('.', $idToken);
    if (count($parts) !== 3) {
        throw new Exception('Malformed JWT');
    }

    [$headerB64, $payloadB64, $sigB64] = $parts;
    $header = json_decode(base64url_decode($headerB64), true);
    if (!isset($header['kid'])) {
        throw new Exception('Missing kid in header');
    }

    // ---- 1️⃣ Fetch Google JWKS (cached for 5 min) ----
    $jwks = apcu_fetch('google_jwks');
    if ($jwks === false) {
        $jwksJson = file_get_contents('https://www.googleapis.com/oauth2/v3/certs');
        if ($jwksJson === false) {
            throw new Exception('Unable to download Google JWKS');
        }
        $jwks = json_decode($jwksJson, true);
        apcu_store('google_jwks', $jwks, 300);
    }

    // ---- 2️⃣ Find matching key ----
    $jwk = null;
    foreach ($jwks['keys'] as $k) {
        if ($k['kid'] === $header['kid']) {
            $jwk = $k;
            break;
        }
    }
    if ($jwk === null) {
        throw new Exception('Matching JWK not found');
    }

    // ---- 3️⃣ Build PEM public key ----
    $rsa = RSA::loadPublicKey([
        'n' => base64url_decode($jwk['n']),
        'e' => base64url_decode($jwk['e']),
    ]);
    $pem = $rsa->getPublicKey();

    // ---- 4️⃣ Verify signature ----
    $signed = $headerB64 . '.' . $payloadB64;
    $signature = base64url_decode($sigB64);
    $algo = $header['alg'] ?? 'RS256';
    $hashAlg = $algo === 'RS256' ? OPENSSL_ALGO_SHA256 : OPENSSL_ALGO_SHA384;

    $valid = openssl_verify($signed, $signature, $pem, $hashAlg);
    if ($valid !== 1) {
        throw new Exception('Invalid token signature');
    }

    // ---- 5️⃣ Decode payload & basic claim checks ----
    $payload = json_decode(base64url_decode($payloadB64), true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid payload JSON');
    }

    // Issuer must be Google
    if (!in_array($payload['iss'], ['https://accounts.google.com', 'accounts.google.com'], true)) {
        throw new Exception('Invalid issuer');
    }

    // Audience must be YOUR client ID
    $expectedAud = GOOGLE_CLIENT_ID; // define in config.php
    $aud = $payload['aud'];
    if (is_array($aud) ? !in_array($expectedAud, $aud, true) : $aud !== $expectedAud) {
        throw new Exception('Audience mismatch');
    }

    // Expiration
    if ($payload['exp'] < time()) {
        throw new Exception('Token expired');
    }

    return $payload;
}

/**
 * Helper: base64url decode (RFC 7515 §2)
 */
function base64url_decode(string $data): string
{
    $b64 = strtr($data, '-_', '+/');
    $pad = strlen($b64) % 4;
    if ($pad) {
        $b64 .= str_repeat('=', 4 - $pad);
    }
    return base64_decode($b64);
}

/**
 * Generate your own JWT for the client.
 * Adjust the payload/expiry to fit your app.
 */
function generateAppJwt(int $userId, string $email): string
{
    $payload = [
        'sub' => $userId,
        'email' => $email,
        'iat' => time(),
        'exp' => time() + 3600, // 1 hour
    ];
    return JWT::encode($payload, JWT_SECRET, 'HS256'); // JWT_SECRET defined in config.php
}

// ---------------------------------------------------------------------
// MAIN ROUTE
// ---------------------------------------------------------------------
$method = $_SERVER['REQUEST_METHOD'] ?? '';
if ($method !== 'POST') {
    sendError('Method not allowed', 405);
}

// Expect JSON body
$raw = file_get_contents('php://input');
$body = json_decode($raw, true);
if (json_last_error() !== JSON_ERROR_NONE) {
    sendError('Invalid JSON payload');
}
$credential = $body['credential'] ?? '';
if (empty($credential)) {
    sendError('Missing credential');
}

// -------------------------------------------------
// Verify Google token
// -------------------------------------------------
try {
    $payload = verifyGoogleIdToken($credential);
} catch (Exception $e) {
    error_log('Google token verification failed: ' . $e->getMessage());
    sendError('Invalid Google credential');
}

// -------------------------------------------------
// Extract useful fields
// -------------------------------------------------
$email         = $payload['email'] ?? null;
$googleSub     = $payload['sub'] ?? null;   // Google user ID
$name          = $payload['name'] ?? null;
$emailVerified = $payload['email_verified'] ?? false;

if (!$email || !$emailVerified) {
    sendError('Email not verified');
}

// -------------------------------------------------
// DB – find or create user
// -------------------------------------------------
try {
    $db   = new Database();
    $conn = $db->getConnection();
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    error_log('DB connection error: ' . $e->getMessage());
    sendError('Database error', 500);
}

// Look for existing user
$stmt = $conn->prepare('SELECT id, email FROM users WHERE email = :email LIMIT 1');
$stmt->execute([':email' => $email]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user) {
    // Existing – issue JWT
    $jwt = generateAppJwt((int)$user['id'], $user['email']);
    sendJson([
        'user'  => [
            'id'             => (int)$user['id'],
            'email'          => $user['email'],
            'email_verified' => true,
        ],
        'token' => $jwt,
    ]);
}

// -------------------------------------------------
// New user – create record
// -------------------------------------------------
$passwordHash = password_hash(bin2hex(random_bytes(32)), PASSWORD_DEFAULT);
$insert = $conn->prepare('INSERT INTO users (email, password_hash, email_verified, google_id, name) VALUES (:email, :pwd, TRUE, :gid, :nm)');
$insert->execute([
    ':email' => $email,
    ':pwd'   => $passwordHash,
    ':gid'   => $googleSub,
    ':nm'    => $name,
]);

$newId = (int)$conn->lastInsertId();
$jwt   = generateAppJwt($newId, $email);

sendJson([
    'user'  => [
        'id'             => $newId,
        'email'          => $email,
        'email_verified' => true,
    ],
    'token' => $jwt,
]);