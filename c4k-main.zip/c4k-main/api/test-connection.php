<?php
// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

// Test 1: PHP is working
$result = [
    'php_version' => phpversion(),
    'tests' => []
];

// Test 2: config.php loads
try {
    require_once 'config.php';
    $result['tests'][] = ['config_loaded' => true];
} catch (Exception $e) {
    $result['tests'][] = ['config_loaded' => false, 'error' => $e->getMessage()];
    echo json_encode($result);
    exit;
}

// Test 3: Database constants exist
$result['tests'][] = [
    'db_constants' => [
        'DB_HOST' => defined('DB_HOST') ? DB_HOST : 'NOT_DEFINED',
        'DB_NAME' => defined('DB_NAME') ? DB_NAME : 'NOT_DEFINED',
        'DB_USER' => defined('DB_USER') ? DB_USER : 'NOT_DEFINED',
        'DB_PASS_SET' => defined('DB_PASS') ? 'YES' : 'NO'
    ]
];

// Test 4: Database connection with detailed error
try {
    // Try direct PDO connection to get actual error
    try {
        $conn = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME,
            DB_USER,
            DB_PASS,
            array(
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
            )
        );
        $result['tests'][] = ['database_connection' => 'SUCCESS'];

        // Test 5: Check if users table exists
        try {
            $stmt = $conn->query("SHOW TABLES LIKE 'users'");
            $tableExists = $stmt->rowCount() > 0;
            $result['tests'][] = ['users_table_exists' => $tableExists];

            // Show all tables
            $stmt = $conn->query("SHOW TABLES");
            $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
            $result['tests'][] = ['all_tables' => $tables];
        } catch (PDOException $e) {
            $result['tests'][] = ['table_check' => 'ERROR', 'error' => $e->getMessage()];
        }
    } catch (PDOException $e) {
        $result['tests'][] = [
            'database_connection' => 'FAILED',
            'error' => $e->getMessage(),
            'error_code' => $e->getCode()
        ];
    }
} catch (Exception $e) {
    $result['tests'][] = ['database_connection' => 'ERROR', 'error' => $e->getMessage()];
}

echo json_encode($result, JSON_PRETTY_PRINT);
