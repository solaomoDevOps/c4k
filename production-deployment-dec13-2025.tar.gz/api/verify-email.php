<?php
require_once 'config.php';

$db = new Database();
$conn = $db->getConnection();

if (!$conn) {
    die('Database connection failed');
}

$token = $_GET['token'] ?? '';

if (empty($token)) {
    showMessage('Invalid Verification Link', 'The verification link is invalid or incomplete.', 'error');
    exit();
}

$query = "SELECT id, email, email_verified, verification_token_expires
          FROM users
          WHERE verification_token = :token
          LIMIT 1";
$stmt = $conn->prepare($query);
$stmt->bindParam(':token', $token);
$stmt->execute();

$user = $stmt->fetch();

if (!$user) {
    showMessage('Invalid Token', 'This verification link is invalid or has already been used.', 'error');
    exit();
}

if ($user['email_verified']) {
    showMessage('Already Verified', 'Your email has already been verified. You can now sign in to your account.', 'success');
    exit();
}

$expiresAt = strtotime($user['verification_token_expires']);
$now = time();

if ($now > $expiresAt) {
    showMessage('Link Expired', 'This verification link has expired. Please sign up again or contact support.', 'error');
    exit();
}

$updateQuery = "UPDATE users
                SET email_verified = TRUE,
                    verification_token = NULL,
                    verification_token_expires = NULL
                WHERE id = :id";
$updateStmt = $conn->prepare($updateQuery);
$updateStmt->bindParam(':id', $user['id']);

if ($updateStmt->execute()) {
    showMessage(
        'Email Verified Successfully!',
        'Your email has been verified. You can now sign in to your Computer4Kids account and start creating profiles for your children.',
        'success'
    );
} else {
    showMessage('Verification Failed', 'An error occurred while verifying your email. Please try again or contact support.', 'error');
}

function showMessage($title, $message, $type) {
    $color = $type === 'success' ? '#10B981' : '#EF4444';
    $icon = $type === 'success' ? '✓' : '✗';

    echo "
    <!DOCTYPE html>
    <html lang='en'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>{$title} - Computer4Kids</title>
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            body {
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 20px;
            }
            .container {
                background: white;
                border-radius: 16px;
                box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
                max-width: 500px;
                width: 100%;
                padding: 40px;
                text-align: center;
            }
            .icon {
                width: 80px;
                height: 80px;
                border-radius: 50%;
                background: {$color};
                color: white;
                font-size: 48px;
                display: flex;
                align-items: center;
                justify-content: center;
                margin: 0 auto 24px;
                font-weight: bold;
            }
            h1 {
                color: #1F2937;
                font-size: 28px;
                margin-bottom: 16px;
            }
            p {
                color: #6B7280;
                font-size: 16px;
                line-height: 1.6;
                margin-bottom: 32px;
            }
            .button {
                display: inline-block;
                background: #4F46E5;
                color: white;
                padding: 12px 32px;
                border-radius: 8px;
                text-decoration: none;
                font-weight: 600;
                transition: background 0.3s ease;
            }
            .button:hover {
                background: #4338CA;
            }
            .footer {
                margin-top: 32px;
                padding-top: 24px;
                border-top: 1px solid #E5E7EB;
                color: #9CA3AF;
                font-size: 14px;
            }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='icon'>{$icon}</div>
            <h1>{$title}</h1>
            <p>{$message}</p>
            <a href='/' class='button'>Go to Computer4Kids</a>
            <div class='footer'>
                &copy; 2024 Computer4Kids. All rights reserved.
            </div>
        </div>
    </body>
    </html>
    ";
}
