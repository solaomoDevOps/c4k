<?php
require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];
$data = getRequestData();

$db = new Database();
$conn = $db->getConnection();

if (!$conn) {
    sendError('Database connection failed', 500);
}

if ($method === 'POST') {
    $action = $_GET['action'] ?? '';

    if ($action === 'google') {
        $credential = $data['credential'] ?? '';

        if (empty($credential)) {
            sendError('Google credential is required');
        }

        $parts = explode('.', $credential);
        if (count($parts) !== 3) {
            sendError('Invalid Google credential format');
        }

        $base64Url = $parts[1];
        $base64 = str_replace(['-', '_'], ['+', '/'], $base64Url);
        $padding = strlen($base64) % 4;
        if ($padding) {
            $base64 .= str_repeat('=', 4 - $padding);
        }

        $decoded = base64_decode($base64);
        if ($decoded === false) {
            sendError('Failed to decode Google credential');
        }

        $payload = json_decode($decoded, true);
        if (!$payload || !isset($payload['email'])) {
            sendError('Invalid Google credential payload');
        }

        $email = $payload['email'];
        $googleId = $payload['sub'] ?? '';
        $name = $payload['name'] ?? '';
        $emailVerified = $payload['email_verified'] ?? false;

        if (!$emailVerified) {
            sendError('Google email not verified');
        }

        $query = "SELECT id, email FROM users WHERE email = :email LIMIT 1";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        $user = $stmt->fetch();

        if ($user) {
            $token = generateToken($user['id'], $user['email']);

            sendResponse([
                'user' => [
                    'id' => $user['id'],
                    'email' => $user['email'],
                    'email_verified' => true
                ],
                'token' => $token
            ]);
        } else {
            $passwordHash = password_hash(bin2hex(random_bytes(32)), PASSWORD_DEFAULT);

            $insertQuery = "INSERT INTO users (email, password_hash, email_verified)
                           VALUES (:email, :password_hash, TRUE)";
            $insertStmt = $conn->prepare($insertQuery);
            $insertStmt->bindParam(':email', $email);
            $insertStmt->bindParam(':password_hash', $passwordHash);

            if ($insertStmt->execute()) {
                $userId = $conn->lastInsertId();
                $token = generateToken($userId, $email);

                sendResponse([
                    'user' => [
                        'id' => $userId,
                        'email' => $email,
                        'email_verified' => true
                    ],
                    'token' => $token
                ]);
            } else {
                sendError('Failed to create account', 500);
            }
        }
    } else {
        sendError('Invalid action', 400);
    }
} else {
    sendError('Method not allowed', 405);
}
