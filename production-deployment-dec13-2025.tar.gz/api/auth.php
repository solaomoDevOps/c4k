<?php
require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];
$data = getRequestData();

$db = new Database();
$conn = $db->getConnection();

if (!$conn) {
    sendError('Database connection failed', 500);
}

function sendVerificationEmail($email, $token) {
    $verificationLink = "https://" . $_SERVER['HTTP_HOST'] . "/api/verify-email.php?token=" . $token;

    $subject = "Verify Your Email - Computer4Kids";
    $message = "
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background-color: #4F46E5; color: white; padding: 20px; text-align: center; border-radius: 5px 5px 0 0; }
            .content { background-color: #f9f9f9; padding: 30px; border-radius: 0 0 5px 5px; }
            .button { display: inline-block; padding: 12px 30px; background-color: #4F46E5; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
            .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1>Welcome to Computer4Kids!</h1>
            </div>
            <div class='content'>
                <h2>Please Verify Your Email Address</h2>
                <p>Thank you for signing up! To complete your registration, please click the button below to verify your email address:</p>
                <p style='text-align: center;'>
                    <a href='{$verificationLink}' class='button'>Verify My Email</a>
                </p>
                <p>Or copy and paste this link into your browser:</p>
                <p style='word-break: break-all; color: #4F46E5;'>{$verificationLink}</p>
                <p>This link will expire in 24 hours.</p>
                <p>If you didn't create an account, please ignore this email.</p>
            </div>
            <div class='footer'>
                <p>&copy; 2024 Computer4Kids. All rights reserved.</p>
            </div>
        </div>
    </body>
    </html>
    ";

    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: Computer4Kids <support@computer4kids.com>" . "\r\n";

    return mail($email, $subject, $message, $headers);
}

if ($method === 'POST') {
    $action = $_GET['action'] ?? '';

    if ($action === 'signup') {
        $email = $data['email'] ?? '';
        $password = $data['password'] ?? '';

        if (empty($email) || empty($password)) {
            sendError('Email and password are required');
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            sendError('Invalid email format');
        }

        if (strlen($password) < 6) {
            sendError('Password must be at least 6 characters');
        }

        $checkQuery = "SELECT id FROM users WHERE email = :email LIMIT 1";
        $stmt = $conn->prepare($checkQuery);
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        if ($stmt->fetch()) {
            sendError('Email already registered');
        }

        $passwordHash = password_hash($password, PASSWORD_DEFAULT);
        $verificationToken = bin2hex(random_bytes(32));
        $expiresAt = date('Y-m-d H:i:s', strtotime('+24 hours'));

        $query = "INSERT INTO users (email, password_hash, verification_token, verification_token_expires)
                  VALUES (:email, :password_hash, :verification_token, :expires_at)";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':password_hash', $passwordHash);
        $stmt->bindParam(':verification_token', $verificationToken);
        $stmt->bindParam(':expires_at', $expiresAt);

        if ($stmt->execute()) {
            $userId = $conn->lastInsertId();

            if (sendVerificationEmail($email, $verificationToken)) {
                sendResponse([
                    'message' => 'Account created! Please check your email to verify your account.',
                    'email_sent' => true,
                    'user' => [
                        'id' => $userId,
                        'email' => $email,
                        'email_verified' => false
                    ]
                ]);
            } else {
                sendError('Account created but failed to send verification email. Please contact support.', 500);
            }
        } else {
            sendError('Failed to create account', 500);
        }
    } elseif ($action === 'signin') {
        $email = $data['email'] ?? '';
        $password = $data['password'] ?? '';

        if (empty($email) || empty($password)) {
            sendError('Email and password are required');
        }

        $query = "SELECT id, email, password_hash, email_verified FROM users WHERE email = :email LIMIT 1";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        $user = $stmt->fetch();

        if (!$user || !password_verify($password, $user['password_hash'])) {
            sendError('Invalid email or password', 401);
        }

        if (!$user['email_verified']) {
            sendError('Please verify your email before signing in. Check your inbox for the verification link.', 403);
        }

        $token = generateToken($user['id'], $user['email']);

        sendResponse([
            'user' => [
                'id' => $user['id'],
                'email' => $user['email'],
                'email_verified' => true
            ],
            'token' => $token
        ]);
    } else {
        sendError('Invalid action', 400);
    }
} elseif ($method === 'GET') {
    $token = getAuthToken();

    if (!$token) {
        sendError('No token provided', 401);
    }

    $user = verifyToken($token);

    if (!$user) {
        sendError('Invalid token', 401);
    }

    sendResponse(['user' => $user]);
} else {
    sendError('Method not allowed', 405);
}
