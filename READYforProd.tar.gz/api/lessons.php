<?php
require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];

$db = new Database();
$conn = $db->getConnection();

if (!$conn) {
    sendError('Database connection failed', 500);
}

if ($method === 'GET') {
    $query = "SELECT * FROM lessons ORDER BY category, lesson_number";
    $stmt = $conn->prepare($query);
    $stmt->execute();

    $lessons = $stmt->fetchAll();

    sendResponse(['lessons' => $lessons]);
} else {
    sendError('Method not allowed', 405);
}
