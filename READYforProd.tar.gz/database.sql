-- Computer Kids Learning MySQL Database Schema
-- This file should be imported into your Hostinger MySQL database

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    email_verified BOOLEAN DEFAULT FALSE,
    verification_token VARCHAR(64) NULL,
    verification_token_expires TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_verification_token (verification_token)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS children (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    name VARCHAR(100) NOT NULL,
    hand_preference ENUM('left', 'right') DEFAULT 'right',
    computer_type ENUM('mac', 'pc') DEFAULT 'pc',
    selected_avatar VARCHAR(50) DEFAULT 'robot',
    career_role VARCHAR(100) NULL,
    xp INT DEFAULT 0,
    level INT DEFAULT 1,
    current_streak INT DEFAULT 0,
    longest_streak INT DEFAULT 0,
    age_group VARCHAR(20) DEFAULT '5-7',
    total_play_time INT DEFAULT 0,
    last_login_date DATE NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS lessons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    category VARCHAR(50) NOT NULL,
    lesson_number INT NOT NULL,
    description TEXT,
    computer_type VARCHAR(20) DEFAULT 'all',
    content JSON NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_category (category),
    INDEX idx_lesson_number (lesson_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS progress (
    id INT AUTO_INCREMENT PRIMARY KEY,
    child_id INT NOT NULL,
    lesson_id INT NOT NULL,
    completed BOOLEAN DEFAULT FALSE,
    score INT DEFAULT 0,
    attempts INT DEFAULT 0,
    time_spent INT DEFAULT 0,
    completed_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (child_id) REFERENCES children(id) ON DELETE CASCADE,
    FOREIGN KEY (lesson_id) REFERENCES lessons(id) ON DELETE CASCADE,
    UNIQUE KEY unique_child_lesson (child_id, lesson_id),
    INDEX idx_child_id (child_id),
    INDEX idx_lesson_id (lesson_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    child_id INT NOT NULL,
    audio_enabled BOOLEAN DEFAULT TRUE,
    text_size ENUM('small', 'medium', 'large') DEFAULT 'medium',
    difficulty_level INT DEFAULT 1,
    screen_time_limit INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (child_id) REFERENCES children(id) ON DELETE CASCADE,
    UNIQUE KEY unique_child_settings (child_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS daily_rewards (
    id INT AUTO_INCREMENT PRIMARY KEY,
    child_id INT NOT NULL,
    reward_date DATE NOT NULL,
    xp_earned INT DEFAULT 10,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (child_id) REFERENCES children(id) ON DELETE CASCADE,
    UNIQUE KEY unique_child_date (child_id, reward_date),
    INDEX idx_child_id (child_id),
    INDEX idx_reward_date (reward_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default lessons
INSERT INTO lessons (title, category, lesson_number, description, computer_type) VALUES
('Moving the Mouse', 'mouse', 1, 'Learn to move the mouse cursor', 'all'),
('Single Click', 'mouse', 2, 'Learn to click buttons', 'all'),
('Double-Click', 'mouse', 3, 'Master double-clicking', 'all'),
('Drag and Drop', 'mouse', 4, 'Learn to drag items', 'all'),
('Keyboard Introduction', 'keyboard', 1, 'Learn keyboard layout', 'all'),
('Hand Placement', 'keyboard', 2, 'Proper hand position', 'all'),
('Type Letters', 'keyboard', 3, 'Practice typing letters', 'all'),
('Type Words', 'keyboard', 4, 'Practice typing words', 'all'),
('What is a Computer?', 'computer-basics', 1, 'Learn about computers', 'all'),
('Power Button', 'computer-basics', 2, 'Turn computer on and off', 'all'),
('Window Controls', 'navigation', 1, 'Minimize, maximize, close', 'all'),
('Menus and Buttons', 'navigation', 2, 'Navigate menus', 'all'),
('Using the Desktop', 'navigation', 3, 'Learn about the desktop and organizing icons', 'all'),
('Opening and Closing Programs', 'navigation', 4, 'Learn to start and exit programs properly', 'all')
ON DUPLICATE KEY UPDATE title=VALUES(title);
